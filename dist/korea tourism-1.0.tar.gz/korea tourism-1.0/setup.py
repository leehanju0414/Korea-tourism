from distutils.core import setup

setup(name='korea tourism',
      version='1.0',
      py_modules=['main', 'kor_api', 'eng_api', 'map_api'],
      )